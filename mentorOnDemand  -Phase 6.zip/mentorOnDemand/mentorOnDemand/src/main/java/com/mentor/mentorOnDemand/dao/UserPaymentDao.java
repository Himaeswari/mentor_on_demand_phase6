package com.mentor.mentorOnDemand.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.mentor.mentorOnDemand.model.UserPayment;

@Repository
public interface UserPaymentDao extends JpaRepository<UserPayment,Long>{

	@Query("Select u from UserPayment u where u.userId= :userId")
	public List<UserPayment> findByUserId(@Param("userId") long userId);

	public UserPayment findByPaymentId(long id);

	public List<UserPayment> findByStatus(String status);

}
