package com.mentor.mentorOnDemand.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mentor.mentorOnDemand.model.Skills;


@Repository
public interface SkillDao extends JpaRepository<Skills,Long>{

	

	Skills findBySkillName(String skills);

	

}
